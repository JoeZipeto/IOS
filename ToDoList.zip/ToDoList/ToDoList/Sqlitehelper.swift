//
//  Sqlitehelper.swift
//  ToDoList
//
//  Created by Tech on 2017-02-28.
//  Copyright © 2017 JZ. All rights reserved.
//

import Foundation


class Sqlitehelper{
    let dbInstance = Sqlitehelper()
    
    let DB: Connection?
    
    let path = NSSearchPathForDirectoriesInDomains(
        .documentDirectory, .userDomainMask, true
        ).first!
    
    let db = try Connection("/todolist.sqlite3")
    
    
    let id = Expression<Int64>("id")
    let task = Expression<String?>("task")

    


}
