//
//  DBHelper.swift
//  ToDoList
//
//  Created by Tech on 2017-02-28.
//  Copyright © 2017 JZ. All rights reserved.
//

import UIKit
import SQLite



class DBHelper {
    
    let tasks = Table("tasks")
    var db: Connection!
    let id = Expression<Int64>("id")
    let task = Expression<String>("task")
    
    //Create the database if it does not exist
    init() {
        let path = NSSearchPathForDirectoriesInDomains(
            .documentDirectory, .userDomainMask, true
            ).first!
        do{
            self.db =  try Connection("\(path)/todolist.sqlite3")
        }catch{
            print ("Cannot Connect to Database")
        }
    }
    
    // Create the Tables if it dosent exists
    func createTable(){
        
        do{
            try db.run(tasks.create(ifNotExists: true){t in t.column(id, primaryKey:true)
                                        t.column(task)})
        }catch{
            print("Connection Not available")
        }
    }
    
    //Insert into database
    func insertTask(insertTask:String?) -> Bool{
        var result = false
        if insertTask != nil{
            do{
               let rowid = try db.run(tasks.insert(self.task <- insertTask!))
                print("Inserted ID: \(rowid)")
                result = true
                
            }
            catch{
                print("Cannot Insert into Database")
                result = true
            }
        }
        return result
    }
    
    //get all tasks from database
    func findAllTasks() -> Array<String>{
        
        var result:Array<String> = []
        do{
            for task in try db.prepare(self.tasks){
                result.append(task.get(self.task))
            }
        }
        catch{
            print("Cannot access the database")
        }
        return result
    }
    
    //Delete tasks from database
    func deleteTask(task:String) {
        let query = tasks.select(self.id, self.task).filter(self.task==task)
        
            do{
                try db.run(query.delete())
                print ("Task Deleted")
                
            }catch{
                print("Task not Found")
            
            
        }
        
    }
    //want to check if the record already exists in the database
    func findtask(task:String) -> Bool {
        
       //    do{
       //  for task1 in try! db.prepare(self.tasks){
       //    if task1.get(self.task) == task{
       //        return false
       //   } else {
      //       return true
      //  }
       
      //      catch{
      //      print("cannot connect to database")
      //     }
        return true
    }
}
