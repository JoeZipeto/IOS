//
//  DBHelper.swift
//  ToDoList
//
//  Created by Tech on 2017-02-28.
//  Copyright © 2017 JZ. All rights reserved.
//

import UIKit
import SQLite



class DBHelper {
    
    let tasks = Table("tasks")
    var db: Connection!
    let id = Expression<Int64>("id")
    let task = Expression<String>("task")
    
    init() {
        let path = NSSearchPathForDirectoriesInDomains(
            .documentDirectory, .userDomainMask, true
            ).first!
        do{
            self.db =  try Connection("\(path)/todolist.sqlite3")
        }catch{
            print ("Cannot Connect to Database")
        }
    }
    
    
    func createTable(){
        
        do{
            try db.run(tasks.create(ifNotExists: true){t in t.column(id, primaryKey:true)
                                        t.column(task)})
        }catch{
            print("Connection Not available")
        }
    }
    
    func insertTask(insertTask:String?){
        if insertTask != nil{
            do{
               let rowid = try db.run(tasks.insert(self.task <- insertTask!))
                print("Inserted ID: \(rowid)")
                
            }
            catch{
                print("Cannot Insert into Database")
            }
        }
    }
    
    func findAllTasks() -> Array<String>{
        
        var result:Array<String> = []
        do{
            for task in try db.prepare(self.tasks){
                result.append(task.get(self.task))
            }
        }
        catch{
            print("Cannot access the database")
        }
        return result
    }
    
    func deleteTask(task:String) {
        let query = tasks.select(self.id, self.task).filter(self.task==task)
        
        if query != nil {
            do{
                try db.run(query.delete())
                print ("Task Deleted")
                
            }catch{
                print("Task not Found")
            
            }
        }
        
    }
}
