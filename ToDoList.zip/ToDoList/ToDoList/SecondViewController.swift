//
//  SecondViewController.swift
//  ToDoList
//
//  Created by C410 on 2017-02-21.
//  Copyright © 2017 JZ. All rights reserved.
//

import UIKit
class SecondViewController: UIViewController {
    @IBOutlet weak var task: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.hideKeyboardWhenTappedAround()
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addTask(_ sender: Any) {
        //insert into sqlite database
        let dbhelper = DBHelper()
        
        if !(task.text?.isEmpty)! {
            print("not empty")
            
            if(dbhelper.findtask(task: task.text!)){
                displayResult(title: "Duplicate", text: "Task already exists")
            } else {
            if (dbhelper.insertTask(insertTask: task.text)){
                displayResult(title: "Complete",text: "Task Inserted")
            
                //clear textfield after inserted
                task.text = ""
            }
            else{
                displayResult(title: "Error", text: "Could not insert task")
            }
        }
        }
        else{
            
            displayResult(title: "Error", text: "Please type a task")
        }
    }
    
    func displayResult(title: String, text:String) {
        let alertController = UIAlertController(title: title, message:
            text, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
        
        self.present(alertController, animated: true, completion: nil)    }
}

extension UIViewController {
    //Copied this code from the web. I need to remove the keyboard when tapped around. If I lose marks for this I will accept it. I did a similar thing in android for capstone but I don't know the commands in swift.
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }

}
