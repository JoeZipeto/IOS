//
//  SecondViewController.swift
//  ToDoList
//
//  Created by C410 on 2017-02-21.
//  Copyright © 2017 JZ. All rights reserved.
//

import UIKit



class SecondViewController: UIViewController {
    
    
    @IBOutlet weak var task: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func addTask(_ sender: Any) {
        
        let dbhelper = DBHelper()
        if !(task.text?.isEmpty)! {
            print("not empty")
            dbhelper.insertTask(insertTask: task.text)
            print("Task Inserted")
        }
        else{
            print("Empty")
        }
    }
    
        }

